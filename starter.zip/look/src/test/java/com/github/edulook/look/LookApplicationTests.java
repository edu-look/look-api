package com.github.edulook.look;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LookApplicationTests {

	@Test
	void contextLoads() {
	}

}
