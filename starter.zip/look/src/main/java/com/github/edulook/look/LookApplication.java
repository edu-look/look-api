package com.github.edulook.look;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LookApplication {

	public static void main(String[] args) {
		SpringApplication.run(LookApplication.class, args);
	}

}
